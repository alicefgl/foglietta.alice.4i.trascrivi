using System;
using System.Collections.Generic;
using System.Text;

public static class TrascrizioneRNA
{
    public static string ToRna(string dna)
    {
        string rna = "";
        if( String.IsNullOrEmpty( dna ) )
            return "";

        for (int i = 0; i < dna.Length; i++){
            if(dna[i].CompareTo('G')==0){
                rna = rna + "C";
            }
            else
            {
                if (dna[i].CompareTo('C')==0)
                {
                    rna = rna + "G";
                }
                else
                {
                    if(dna[i].CompareTo('T')==0){
                        rna = rna + 'A';
                    }
                    else{
                        if(dna[i].CompareTo('A')==0){
                            rna = rna + "U";
                        }
                    }
                }
            }
        }
        dna = rna;
        return dna;
    }
}